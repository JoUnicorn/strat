from django.shortcuts import render
from django.http import JsonResponse
import QuantLib as ql

def option_price(spot_price,strike_price,volatility,dividend_rate,risk_free_rate,option,jours):
    if option=="Call":
        option_type = ql.Option.Call
    else:
        option_type = ql.Option.Put
    x=16
    calculation_date = ql.Date(1, 1, 2018)
    maturity_date = calculation_date+jours

    day_count = ql.Actual365Fixed()
    calendar = ql.UnitedStates()

    ql.Settings.instance().evaluationDate = calculation_date

    payoff = ql.PlainVanillaPayoff(option_type, strike_price)
    settlement = calculation_date

    am_exercise = ql.AmericanExercise(settlement, maturity_date)
    american_option = ql.VanillaOption(payoff, am_exercise)

    spot_handle = ql.QuoteHandle(
        ql.SimpleQuote(spot_price)
    )
    flat_ts = ql.YieldTermStructureHandle(
        ql.FlatForward(calculation_date, risk_free_rate, day_count)
    )
    dividend_yield = ql.YieldTermStructureHandle(
        ql.FlatForward(calculation_date, dividend_rate, day_count)
    )
    flat_vol_ts = ql.BlackVolTermStructureHandle(
        ql.BlackConstantVol(calculation_date, calendar, volatility, day_count)
    )
    bsm_process = ql.BlackScholesMertonProcess(spot_handle,
                                               dividend_yield,
                                               flat_ts,
                                               flat_vol_ts)

    steps = 200
    binomial_engine = ql.BinomialVanillaEngine(bsm_process, "crr", steps)
    american_option.setPricingEngine(binomial_engine)
    return american_option.NPV()

# Create your views here.
def price_option(request):
    context={"price_option":"active"}
    return render(request, 'price_option.html', context)

def priceCalculate(request):
    xs=[]
    ys=[]
    try:
        spotPrice = float(request.GET.get('spotPrice', None))
        strike = float(request.GET.get('strike', None))
        vol = float(request.GET.get('vol', None))
        dividend = float(request.GET.get('dividend', None))
        frr = float(request.GET.get('frr', None))
        cp = request.GET.get('cp', None)
        mat = int(request.GET.get('mat', None))
        lenght = int(request.GET.get('lenght', None))
        if lenght=="":
            lenght=60

        x=[];
        y=[];
        res=option_price(spotPrice,strike,vol,dividend,frr,cp,mat)
        for i in range(lenght):
            j=int(lenght/2/10)-i/10
            x.append(spotPrice+j)
            y.append(option_price(spotPrice+j,strike,vol,dividend,frr,cp,mat))

        xs = ';'.join(str(e) for e in x)
        ys = ';'.join(str(e) for e in y)
    except:
        res="error"

    return JsonResponse({"result":res,"xs":xs,"ys":ys}, safe=False)
