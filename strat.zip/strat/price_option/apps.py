from django.apps import AppConfig


class PriceOptionConfig(AppConfig):
    name = 'price_option'
