from django.shortcuts import render
from django.contrib import messages
from django.http import JsonResponse

def index(request):
    context={};
    return render(request, 'home.html', context)
