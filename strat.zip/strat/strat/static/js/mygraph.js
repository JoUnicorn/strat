optionPie = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    series: [
        {
            name:'Pie',
            type:'pie',
            radius: ['50%', '70%'],
            avoidLabelOverlap: false,
            label: {
                normal: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    show: true,
                    textStyle: {
                        fontSize: '30',
                        fontWeight: 'bold'
                    }
                }
            },
            labelLine: {
                normal: {
                    show: false
                }
            },
            data:[]
        }
    ]
};

optionLineDateTime = {
    grid: {
        bottom: 130,
        left:100
    },
    tooltip: {
        trigger: 'axis',
        position: function (pt, params, dom, rect, size) {
            return [pt[0]-size.contentSize[0], '10%'];
        }
    },
    xAxis: [{
        type: 'time',
        axisLabel: {
            rotate:45,
            formatter: (function(value){
                return moment(value).tz('America/Bogota').format('DD/MM/YY, HH:mm:ss');
            })
        },
        axisLine: {onZero: false}
    }],
    yAxis: {
        type: 'value',
        axisLine: {onZero: false}
    },
    dataZoom: [{
        type: 'inside',
        start: 0,
        end: 100
    }, {
        start: 0,
        end: 100,
        handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
        handleSize: '80%',
        handleStyle: {
            color: '#fff',
            shadowBlur: 3,
            shadowColor: 'rgba(0, 0, 0, 0.6)',
            shadowOffsetX: 2,
            shadowOffsetY: 2
        }
    }],
    series: [{
        data: [],
        type:'line',
        smooth:true,
        symbolSize: 10,
        sampling: 'average',
        itemStyle: {
            color: 'rgb(255, 70, 131)'
        },
    }]
};

optionLine = {
    tooltip: {
        trigger: 'axis'
    },
    xAxis: {
        type: 'category',
        data: []
    },
    yAxis: {
        type: 'value'
    },
    dataZoom: [{
        type: 'inside',
        start: 0,
        end: 100
    }, {
        start: 0,
        end: 100,
        handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
        handleSize: '80%',
        handleStyle: {
            color: '#fff',
            shadowBlur: 3,
            shadowColor: 'rgba(0, 0, 0, 0.6)',
            shadowOffsetX: 2,
            shadowOffsetY: 2
        }
    }],
    series: [{
        data: [],
        type:'line',
        smooth:true,
        symbol: 'none',
        sampling: 'average',
        itemStyle: {
            color: 'rgb(255, 70, 131)'
        }
    }]
};

function getLevelOption() {
    return [
        {
            itemStyle: {
                normal: {
                    borderColor: '#777',
                    borderWidth: 0,
                    gapWidth: 1
                }
            },
            upperLabel: {
                normal: {
                    show: true
                }
            }
        },
        {
            itemStyle: {
                normal: {
                    borderColor: '#555',
                    borderWidth: 5,
                    gapWidth: 1
                },
                emphasis: {
                    borderColor: '#ddd'
                }
            }
        },
        {
            colorSaturation: [0.35, 0.5],
            itemStyle: {
                normal: {
                    borderWidth: 5,
                    gapWidth: 1,
                    borderColorSaturation: 0.6
                }
            }
        }
    ];
}

function resize_graph(name_graph,graph,size,container,slider){
  size_domain_chart=$("#"+name_graph).parent().width()+size*$("#"+name_graph).parent().width()/$( "#"+container ).width();
  $( "#"+slider ).click(function() {
    $("#"+name_graph).width(size_domain_chart);
    graph.resize();
    size_domain_chart=$("#"+name_graph).parent().width();
  });
}

optionBarHor = {
    grid: [{
        left: '3%',
        right: '4%',
        bottom: '3%',
        top:40,
        containLabel: true
    }],
    tooltip : {
        trigger: 'axis',
        axisPointer : {
            type : 'shadow'
        }
    },
    yAxis: {
        type: 'category',
    },
    xAxis: {
        type: 'value'
    },
};
