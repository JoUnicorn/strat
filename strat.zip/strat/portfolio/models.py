from django.db import models

# Create your models here.
class Models(models.Model):
    name = models.CharField(max_length=50)

class Model_stocks(models.Model):
    model = models.ForeignKey('Models', on_delete=models.CASCADE, null=True)
    stock = models.CharField(max_length=50)
    s0 = models.FloatField()
    pos = models.FloatField()

class Model_options(models.Model):
    model = models.ForeignKey('Models', on_delete=models.CASCADE, null=True)
    option = models.CharField(max_length=50)
    type = models.CharField(max_length=10)
    s0 = models.FloatField()
    pos = models.FloatField()
    strike = models.FloatField()
    volatility = models.FloatField()
    maturity = models.IntegerField()
