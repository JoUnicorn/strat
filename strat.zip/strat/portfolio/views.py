from django.shortcuts import render
from portfolio.models import Models, Model_stocks, Model_options
from portfolio.forms import Models_form, Model_stocks_form, Model_options_form
from django.contrib import messages
from django.http import JsonResponse
import QuantLib as ql

def option_price(spot_price,strike_price,volatility,dividend_rate,risk_free_rate,option,jours):
    if option=="Call":
        option_type = ql.Option.Call
    else:
        option_type = ql.Option.Put
    x=16
    calculation_date = ql.Date(1, 1, 2018)
    maturity_date = calculation_date+jours

    day_count = ql.Actual365Fixed()
    calendar = ql.UnitedStates()

    ql.Settings.instance().evaluationDate = calculation_date

    payoff = ql.PlainVanillaPayoff(option_type, strike_price)
    settlement = calculation_date

    am_exercise = ql.AmericanExercise(settlement, maturity_date)
    american_option = ql.VanillaOption(payoff, am_exercise)

    spot_handle = ql.QuoteHandle(
        ql.SimpleQuote(spot_price)
    )
    flat_ts = ql.YieldTermStructureHandle(
        ql.FlatForward(calculation_date, risk_free_rate, day_count)
    )
    dividend_yield = ql.YieldTermStructureHandle(
        ql.FlatForward(calculation_date, dividend_rate, day_count)
    )
    flat_vol_ts = ql.BlackVolTermStructureHandle(
        ql.BlackConstantVol(calculation_date, calendar, volatility, day_count)
    )
    bsm_process = ql.BlackScholesMertonProcess(spot_handle,
                                               dividend_yield,
                                               flat_ts,
                                               flat_vol_ts)

    steps = 200
    binomial_engine = ql.BinomialVanillaEngine(bsm_process, "crr", steps)
    american_option.setPricingEngine(binomial_engine)
    return american_option.NPV()

# Create your views here.
def ptf(request):
    models= Models.objects.all()
    context={"ptf":"active", 'Models_form': Models_form, "models":models, 'Model_stocks_form': Model_stocks_form, 'Model_options_form': Model_options_form};
    if request.method == "POST":
        if 'save_model' in request.POST:
            Models_form_sub = Models_form(request.POST)
            if Models_form_sub.is_valid():
                name = Models_form_sub.cleaned_data['name']
                try:
                    model= Models.objects.get(name=name)
                except Models.DoesNotExist:
                    model = None

                if model is not None:
                    error = "Model already exists."
                    messages.warning(request, error)

                else:
                    model_s=Models(name=name)
                    model_s.save()
                    error = "Model saved"
                    p=Models.objects.get(name=name)
                    context["selected_model"]=p.id
                    messages.warning(request, error)
            else:
                error = "Form is not valid: your name is too long (max lenght: 50)"
                messages.warning(request, error)
    return render(request, 'ptf.html', context)

def delete_source(request):
    idModel = request.GET.get('idModel', None)
    nameModel = request.GET.get('nameModel', None)
    Models.objects.filter(id=idModel).delete()
    return JsonResponse({"result":nameModel}, safe=False)

def delete_stock(request):
    idModel = request.GET.get('idModel', None)
    nameModel = request.GET.get('nameModel', None)
    Model_stocks.objects.filter(id=idModel).delete()
    return JsonResponse({"result":nameModel}, safe=False)

def delete_option(request):
    idModel = request.GET.get('idModel', None)
    nameModel = request.GET.get('nameModel', None)
    Model_options.objects.filter(id=idModel).delete()
    return JsonResponse({"result":nameModel}, safe=False)

def add_stock(request):
    error=""
    pid=""
    idModel = request.GET.get('idModel', None)
    stock = request.GET.get('stock', None)
    bs = request.GET.get('bs', None)
    if stock=="":
        error="Input error"
    try:
        s0 = float(request.GET.get('s0', None))
        pos = int(request.GET.get('pos', None))
    except:
        error="Input error"
        s0=0
        pos=0

    if error=="":
        try:
            stock_s= Model_stocks.objects.get(stock=stock,model=Models.objects.get(id=idModel))
        except Model_stocks.DoesNotExist:
            stock_s = None

        if stock_s is not None:
            error = "Stock already exists."

        else:
            model_s_s=Model_stocks(model=Models.objects.get(id=idModel),bs=bs,stock=stock,s0=s0,pos=pos)
            model_s_s.save()
            p=Model_stocks.objects.get(model=Models.objects.get(id=idModel),stock=stock)
            pid=p.id

    return JsonResponse({"result":stock,"error":error,"id":pid,"bs":bs,"s0":s0,"pos":pos}, safe=False)

def add_option(request):
    error=""
    pid=""
    idModel = request.GET.get('idModel', None)
    option = request.GET.get('option', None)
    type = request.GET.get('type', None)
    bs = request.GET.get('bs', None)
    if option=="":
        error="Input error"
    try:
        s0 = float(request.GET.get('s0', None))
        pos = int(request.GET.get('pos', None))
        strike = float(request.GET.get('strike', None))
        vol = float(request.GET.get('vol', None))
        mat = int(request.GET.get('mat', None))
    except:
        error="Input error"
        s0=0
        pos=0
        strike=0
        vol=0
        mat=0

    if error=="":
        try:
            stock_s= Model_options.objects.get(option=option,model=Models.objects.get(id=idModel))
        except Model_options.DoesNotExist:
            stock_s = None

        if stock_s is not None:
            error = "Stock already exists."

        else:
            model_s_s=Model_options(model=Models.objects.get(id=idModel),option=option,bs=bs,s0=s0,pos=pos,type=type,strike=strike,volatility=vol,maturity=mat)
            model_s_s.save()
            p=Model_options.objects.get(model=Models.objects.get(id=idModel),option=option)
            pid=p.id

    return JsonResponse({"result":option,"error":error,"id":pid,"bs":bs,"s0":s0,"pos":pos,"strike":strike,"vol":vol,"mat":mat,"type":type}, safe=False)

def change_stock(request):
    error=""
    pid=""
    idModel = request.GET.get('idModel', None)
    bs = request.GET.get('bs', None)
    try:
        s0 = float(request.GET.get('s0', None))
        pos = int(request.GET.get('pos', None))
    except:
        error="Input error"
        s0=0
        pos=0

    if error=="":
        p=Model_stocks.objects.get(id=idModel)
        p.s0=s0
        p.pos=pos
        p.bs=bs
        p.save()

    return JsonResponse({"error":error,"id":idModel,"bs":bs,"s0":s0,"pos":pos}, safe=False)

def change_option(request):
    error=""
    pid=""
    idModel = request.GET.get('idModel', None)
    type = request.GET.get('type', None)
    bs = request.GET.get('bs', None)
    if type=="":
        error="Input error"
    try:
        s0 = float(request.GET.get('s0', None))
        pos = int(request.GET.get('pos', None))
        strike = float(request.GET.get('strike', None))
        vol = float(request.GET.get('vol', None))
        mat = int(request.GET.get('mat', None))
    except:
        error="Input error"
        s0=0
        pos=0
        strike=0
        vol=0
        mat=0

    if error=="":
        p=Model_options.objects.get(id=idModel)
        p.s0=s0
        p.pos=pos
        p.type=type
        p.strike=strike
        p.volatility=vol
        p.maturity=mat
        p.bs=bs
        p.save()

    return JsonResponse({"error":error,"id":idModel,"bs":bs,"s0":s0,"pos":pos,"strike":strike,"vol":vol,"mat":mat,"type":type}, safe=False)

def pnl_stock(request):
    s0 = float(request.GET.get('s0', None))
    pos = int(request.GET.get('pos', None))
    bs = request.GET.get('bs', None)
    pnlxs=""
    pnlys=""
    length=float(request.GET.get('interval', None))
    pas=float(request.GET.get('step', None))
    x=[]
    y=[]
    sign=1
    if bs=="sell":
        sign=-1
    for i in range(int(length/pas)):
        x.append(s0-int(length/2*100)/100+pas*i)
        y.append(sign*int(((pas*i-int(length/2*100)/100)*pos)*100)/100)

    pnlxs = ';'.join(str(e) for e in x)
    pnlys = ';'.join(str(e) for e in y)

    return JsonResponse({"pnlxs":pnlxs,"pnlys":pnlys}, safe=False)

def pnl_option(request):
    s0 = float(request.GET.get('s0', None))
    pos = int(request.GET.get('pos', None))
    bs = request.GET.get('bs', None)
    strike = float(request.GET.get('strike', None))
    vol = float(request.GET.get('vol', None))
    mat = int(request.GET.get('mat', None))
    dividend = 0
    frr = 0.01
    cp = request.GET.get('type', None)
    pnlxs=""
    pnlys=""
    length=float(request.GET.get('interval', None))
    pas=float(request.GET.get('step', None))
    x=[]
    y=[]
    mult=100
    sign=1
    if bs=="sell":
        sign=-1
    ref=int(option_price(s0,strike,vol,dividend,frr,cp,mat)*100)/100
    for i in range(int(length/pas)):
        x.append(s0-int(length/2*100)/100+pas*i)
        y.append(sign*(int(option_price(s0-int(length/2*100)/100+pas*i,strike,vol,dividend,frr,cp,mat)*100)/100-ref)*mult*pos)

    pnlxs = ';'.join(str(e) for e in x)
    pnlys = ';'.join(str(e) for e in y)

    return JsonResponse({"pnlxs":pnlxs,"pnlys":pnlys}, safe=False)
