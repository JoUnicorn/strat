from django.shortcuts import render
from portfolio.models import Models, Model_stocks, Model_options
from portfolio.forms import Models_form, Model_stocks_form, Model_options_form
from django.contrib import messages
from django.http import JsonResponse

# Create your views here.
def ptf(request):
    models= Models.objects.all()
    context={"ptf":"active", 'Models_form': Models_form, "models":models, 'Model_stocks_form': Model_stocks_form, 'Model_options_form': Model_options_form};
    if request.method == "POST":
        if 'save_model' in request.POST:
            Models_form_sub = Models_form(request.POST)
            if Models_form_sub.is_valid():
                name = Models_form_sub.cleaned_data['name']
                try:
                    model= Models.objects.get(name=name)
                except Models.DoesNotExist:
                    model = None

                if model is not None:
                    error = "Model already exists."
                    messages.warning(request, error)

                else:
                    model_s=Models(name=name)
                    model_s.save()
                    error = "Model saved"
                    p=Models.objects.get(name=name)
                    context["selected_model"]=p.id
                    messages.warning(request, error)
            else:
                error = "Form is not valid: your name is too long (max lenght: 50)"
                messages.warning(request, error)
    return render(request, 'ptf.html', context)

def delete_source(request):
    idModel = request.GET.get('idModel', None)
    nameModel = request.GET.get('nameModel', None)
    Models.objects.filter(id=idModel).delete()
    return JsonResponse({"result":nameModel}, safe=False)

def delete_stock(request):
    idModel = request.GET.get('idModel', None)
    nameModel = request.GET.get('nameModel', None)
    Model_stocks.objects.filter(id=idModel).delete()
    return JsonResponse({"result":nameModel}, safe=False)

def delete_option(request):
    idModel = request.GET.get('idModel', None)
    nameModel = request.GET.get('nameModel', None)
    Model_options.objects.filter(id=idModel).delete()
    return JsonResponse({"result":nameModel}, safe=False)

def add_stock(request):
    error=""
    pid=""
    idModel = request.GET.get('idModel', None)
    stock = request.GET.get('stock', None)
    if stock=="":
        error="Input error"
    try:
        s0 = float(request.GET.get('s0', None))
        pos = int(request.GET.get('pos', None))
    except:
        error="Input error"

    if error=="":
        try:
            stock_s= Model_stocks.objects.get(stock=stock,model=Models.objects.get(id=idModel))
        except Model_stocks.DoesNotExist:
            stock_s = None

        if stock_s is not None:
            error = "Stock already exists."

        else:
            model_s_s=Model_stocks(model=Models.objects.get(id=idModel),stock=stock,s0=s0,pos=pos)
            model_s_s.save()
            p=Model_stocks.objects.get(model=Models.objects.get(id=idModel),stock=stock)
            pid=p.id

    return JsonResponse({"result":stock,"error":error,"id":pid,"s0":s0,"pos":pos}, safe=False)

def add_option(request):
    error=""
    pid=""
    idModel = request.GET.get('idModel', None)
    option = request.GET.get('option', None)
    type = request.GET.get('type', None)
    if option=="":
        error="Input error"
    try:
        s0 = float(request.GET.get('s0', None))
        pos = int(request.GET.get('pos', None))
        strike = float(request.GET.get('strike', None))
        vol = float(request.GET.get('vol', None))
        mat = int(request.GET.get('mat', None))
    except:
        error="Input error"

    if error=="":
        try:
            stock_s= Model_options.objects.get(option=option,model=Models.objects.get(id=idModel))
        except Model_options.DoesNotExist:
            stock_s = None

        if stock_s is not None:
            error = "Stock already exists."

        else:
            model_s_s=Model_options(model=Models.objects.get(id=idModel),option=option,s0=s0,pos=pos,type=type,strike=strike,volatility=vol,maturity=mat)
            model_s_s.save()
            p=Model_options.objects.get(model=Models.objects.get(id=idModel),option=option)
            pid=p.id

    return JsonResponse({"result":option,"error":error,"id":pid,"s0":s0,"pos":pos,"strike":strike,"vol":vol,"mat":mat,"type":type}, safe=False)
