from django.contrib import admin
from .models import Models, Model_stocks, Model_options

class Models_admin(admin.ModelAdmin):
    list_display = ("id",'name')
    search_fields = ("id",'name')

admin.site.register(Models, Models_admin)

class Model_stocks_admin(admin.ModelAdmin):
    list_display = ("id",'model',"bs",'stock','s0','pos')
    search_fields = ("id",'model',"bs",'stock','s0','pos')

admin.site.register(Model_stocks, Model_stocks_admin)

class Model_options_admin(admin.ModelAdmin):
    list_display = ("id",'model',"bs",'option',"type",'s0','pos',"strike","volatility","maturity","maturity2")
    search_fields = ("id",'model',"bs",'option',"type",'s0','pos',"strike","volatility","maturity","maturity2")

admin.site.register(Model_options, Model_options_admin)
