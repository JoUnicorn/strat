from django import forms
from portfolio.models import Models, Model_stocks, Model_options

class Models_form(forms.Form):
    name = forms.CharField(label='Model name (max length: 50)', max_length=50, required=True)

    def __init__(self, *args, **kwargs):
        super(Models_form, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['class'] = 'form-control'

class Model_stocks_form(forms.Form):
    model = forms.CharField(max_length=50, required=True, label="")
    stock = forms.CharField(label='Stock name (max length: 50)', max_length=50, required=True)
    bs = forms.ChoiceField(choices = [("buy","buy"),("sell","sell")],label='buy/sell', required=False)
    s0 = forms.FloatField(label='S0', required=True)
    pos = forms.FloatField(label='Position', required=True)

    def __init__(self, *args, **kwargs):
        super(Model_stocks_form, self).__init__(*args, **kwargs)
        self.fields['model'].widget.attrs['class'] = 'form-control d-none'
        self.fields['model'].widget.attrs['id'] = "IdModel"
        self.fields['stock'].widget.attrs['class'] = 'form-control'
        self.fields['stock'].widget.attrs['id'] = "stockName"
        self.fields['bs'].widget.attrs['class'] = 'form-control'
        self.fields['bs'].widget.attrs['id'] = 'stockBs'
        self.fields['s0'].widget.attrs['class'] = 'form-control'
        self.fields['s0'].widget.attrs['id'] = 's0'
        self.fields['pos'].widget.attrs['class'] = 'form-control'
        self.fields['pos'].widget.attrs['id'] = 'stockPos'

class Model_options_form(forms.Form):
    model = forms.CharField(max_length=50, required=True, label="")
    option = forms.CharField(label='Option name (max length: 50)', max_length=50, required=True)
    type = forms.ChoiceField(choices = [("Call","Call"),("Put","Put")],label='Type', required=False)
    bs = forms.ChoiceField(choices = [("buy","buy"),("sell","sell")],label='buy/sell', required=False)
    s0 = forms.FloatField(label='S0', required=True)
    strike = forms.FloatField(label='Strike', required=True)
    pos = forms.FloatField(label='Position', required=True)
    volatility = forms.FloatField(label='Volatility', required=True)
    maturity = forms.IntegerField(label='Maturity', required=True)
    maturity2 = forms.IntegerField(label='Maturity end', required=True)

    def __init__(self, *args, **kwargs):
        super(Model_options_form, self).__init__(*args, **kwargs)
        self.fields['model'].widget.attrs['class'] = 'form-control d-none'
        self.fields['model'].widget.attrs['id'] = "IdModelOpt"
        self.fields['option'].widget.attrs['class'] = 'form-control'
        self.fields['option'].widget.attrs['id'] = "optionName"
        self.fields['s0'].widget.attrs['class'] = 'form-control'
        self.fields['s0'].widget.attrs['id'] = 'options0'
        self.fields['pos'].widget.attrs['class'] = 'form-control'
        self.fields['pos'].widget.attrs['id'] = 'optionPos'
        self.fields['type'].widget.attrs['class'] = 'form-control'
        self.fields['type'].widget.attrs['id'] = 'optionType'
        self.fields['bs'].widget.attrs['class'] = 'form-control'
        self.fields['bs'].widget.attrs['id'] = 'optionBs'
        self.fields['strike'].widget.attrs['class'] = 'form-control'
        self.fields['strike'].widget.attrs['id'] = 'optionStrike'
        self.fields['volatility'].widget.attrs['class'] = 'form-control'
        self.fields['volatility'].widget.attrs['id'] = 'optionVol'
        self.fields['maturity'].widget.attrs['class'] = 'form-control'
        self.fields['maturity'].widget.attrs['id'] = 'optionMat'
        self.fields['maturity2'].widget.attrs['class'] = 'form-control'
        self.fields['maturity2'].widget.attrs['id'] = 'optionMat2'
